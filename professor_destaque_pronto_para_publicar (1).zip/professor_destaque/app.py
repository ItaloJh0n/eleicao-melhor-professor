import os, sqlite3, secrets, hashlib, csv, io, hmac, time
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, session, flash, Response, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get('DATABASE_PATH', str(BASE / 'data' / 'votacao.db')))
DB.parent.mkdir(parents=True, exist_ok=True)
app = Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get('SECRET_KEY', secrets.token_hex(32)), SESSION_COOKIE_HTTPONLY=True,
                  SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE','0')=='1',
                  MAX_CONTENT_LENGTH=2*1024*1024)
SCHOOLS = ['U. E. José Martins — ANEXO','U. E. José Martins — SEDE','U. E. Lucrécio Dantas',
           'Unidade Escolar Joana Nonata da Silva','Unidade Escolar Melquíades José da Silva',
           'Unidade Escolar Raimundo Lopes','Unidade Escolar Raimundo Rodrigues']
CRITERIA = ['Compromisso','Responsabilidade','Intencionalidade pedagógica','Ética profissional']

def conn():
    c = sqlite3.connect(DB, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=20000')
    return c

def init():
    with conn() as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.executescript('''
        CREATE TABLE IF NOT EXISTS schools(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
        CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY, school_id INTEGER NOT NULL REFERENCES schools(id), name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, UNIQUE(school_id,name));
        CREATE TABLE IF NOT EXISTS codes(id INTEGER PRIMARY KEY, school_id INTEGER NOT NULL REFERENCES schools(id), code_hash TEXT NOT NULL UNIQUE, label TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS votes(id INTEGER PRIMARY KEY, code_id INTEGER NOT NULL UNIQUE REFERENCES codes(id), teacher_id INTEGER NOT NULL REFERENCES teachers(id), school_id INTEGER NOT NULL REFERENCES schools(id), created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, event TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts(ip_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_votes_school ON votes(school_id);
        CREATE INDEX IF NOT EXISTS idx_attempts_time ON attempts(created_at);
        ''')
        for name in SCHOOLS: c.execute('INSERT OR IGNORE INTO schools(name) VALUES (?)',(name,))
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES ('open','0')")

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def digest(v): return hashlib.sha256(v.encode('utf-8')).hexdigest()
def log(c,event,detail=''): c.execute('INSERT INTO audit(event,detail,created_at) VALUES (?,?,?)',(event,detail[:500],now()))
def setting(c,key):
    r=c.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
    return r['value'] if r else None

def csrf():
    if '_csrf' not in session: session['_csrf']=secrets.token_urlsafe(32)
    return session['_csrf']
app.jinja_env.globals['csrf_token']=csrf
@app.before_request
def protect():
    if request.method=='POST':
        if not hmac.compare_digest(request.form.get('_csrf',''),session.get('_csrf','not-set')): abort(400)
@app.after_request
def headers(resp):
    resp.headers['X-Content-Type-Options']='nosniff'
    resp.headers['X-Frame-Options']='DENY'
    resp.headers['Referrer-Policy']='no-referrer'
    resp.headers['Cache-Control']='no-store'
    resp.headers['Content-Security-Policy']="default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    return resp

def admin_only(f):
    @wraps(f)
    def wrapper(*args,**kwargs):
        if not session.get('admin'): return redirect(url_for('login'))
        return f(*args,**kwargs)
    return wrapper

def limited(c):
    # Hash IP with deployment secret; no raw IP retained.
    ip = request.remote_addr or 'unknown'
    key = digest(app.secret_key+'|'+ip)
    ts=int(time.time())
    c.execute('DELETE FROM attempts WHERE created_at<?',(ts-3600,))
    count=c.execute('SELECT COUNT(*) n FROM attempts WHERE ip_hash=?',(key,)).fetchone()['n']
    c.execute('INSERT INTO attempts(ip_hash,created_at) VALUES (?,?)',(key,ts))
    return count>=30

@app.get('/')
def index():
    with conn() as c:
        schools=c.execute('SELECT id,name FROM schools ORDER BY id').fetchall()
        opened=setting(c,'open')=='1'
    return render_template('index.html',schools=schools,opened=opened)

@app.post('/verificar')
def verify():
    code=request.form.get('code','').strip().upper().replace(' ','')
    with conn() as c:
        if limited(c): flash('Muitas tentativas. Aguarde uma hora e tente novamente.','error'); return redirect(url_for('index'))
        if setting(c,'open')!='1': flash('A votação está encerrada.','error'); return redirect(url_for('index'))
        r=c.execute('''SELECT codes.id code_id,schools.id school_id,schools.name school_name,
            (SELECT id FROM votes WHERE code_id=codes.id) voted
            FROM codes JOIN schools ON schools.id=codes.school_id WHERE code_hash=?''',(digest(code),)).fetchone()
        if not r: flash('Código não encontrado. Confira o código recebido da escola.','error'); return redirect(url_for('index'))
        if r['voted']: flash('Este código já foi utilizado. Cada estudante pode votar uma única vez.','error'); return redirect(url_for('index'))
        teachers=c.execute('SELECT id,name FROM teachers WHERE school_id=? AND active=1 ORDER BY name',(r['school_id'],)).fetchall()
    session['voter_code']=code
    return render_template('vote.html',school=r['school_name'],teachers=teachers,criteria=CRITERIA)

@app.post('/votar')
def vote():
    code=session.get('voter_code','')
    teacher=request.form.get('teacher','')
    if not code: return redirect(url_for('index'))
    try: teacher_id=int(teacher)
    except ValueError: abort(400)
    c=conn()
    try:
        c.execute('BEGIN IMMEDIATE')
        if setting(c,'open')!='1': flash('A votação está encerrada.','error'); return redirect(url_for('index'))
        r=c.execute('SELECT id,school_id FROM codes WHERE code_hash=?',(digest(code),)).fetchone()
        if not r: abort(400)
        t=c.execute('SELECT id FROM teachers WHERE id=? AND school_id=? AND active=1',(teacher_id,r['school_id'])).fetchone()
        if not t: flash('Selecione um professor válido da sua escola.','error'); return redirect(url_for('index'))
        c.execute('INSERT INTO votes(code_id,teacher_id,school_id,created_at) VALUES (?,?,?,?)',(r['id'],teacher_id,r['school_id'],now()))
        log(c,'vote_cast',f'vote_id={c.execute("SELECT last_insert_rowid()").fetchone()[0]} school_id={r["school_id"]}')
        c.commit()
    except sqlite3.IntegrityError:
        c.rollback(); flash('Este código já registrou um voto.','error'); return redirect(url_for('index'))
    finally: c.close()
    session.pop('voter_code',None)
    return render_template('success.html')

@app.route('/admin/entrar',methods=['GET','POST'])
def login():
    if request.method=='POST':
        with conn() as c:
            if limited(c): flash('Muitas tentativas. Tente novamente mais tarde.','error'); return redirect(url_for('login'))
        expected=os.environ.get('ADMIN_PASSWORD_HASH','')
        password=request.form.get('password','')
        if (expected and check_password_hash(expected,password)) or (not expected and os.environ.get('ADMIN_PASSWORD') and hmac.compare_digest(os.environ['ADMIN_PASSWORD'],password)):
            session.clear(); session['admin']=True
            return redirect(url_for('admin'))
        flash('Senha inválida ou administrador não configurado.','error')
    return render_template('login.html')

@app.post('/admin/sair')
@admin_only
def logout(): session.clear(); return redirect(url_for('index'))

@app.get('/admin')
@admin_only
def admin():
    with conn() as c:
        schools=c.execute('SELECT * FROM schools ORDER BY id').fetchall()
        stats=c.execute('''SELECT s.id,s.name,(SELECT COUNT(*) FROM teachers t WHERE t.school_id=s.id AND t.active=1) teachers,
            (SELECT COUNT(*) FROM codes co WHERE co.school_id=s.id) codes,
            (SELECT COUNT(*) FROM votes v WHERE v.school_id=s.id) votes FROM schools s ORDER BY s.id''').fetchall()
        results=c.execute('''SELECT s.name school,t.name teacher,COUNT(v.id) total FROM teachers t JOIN schools s ON s.id=t.school_id
          LEFT JOIN votes v ON v.teacher_id=t.id GROUP BY t.id ORDER BY s.id,total DESC,t.name''').fetchall()
        opened=setting(c,'open')=='1'
    return render_template('admin.html',schools=schools,stats=stats,results=results,opened=opened)

@app.post('/admin/professor')
@admin_only
def add_teacher():
    try: school_id=int(request.form.get('school',''))
    except ValueError: abort(400)
    name=' '.join(request.form.get('name','').strip().split())
    if not (3<=len(name)<=120): flash('Nome inválido.','error'); return redirect(url_for('admin'))
    with conn() as c:
        try:
            c.execute('INSERT INTO teachers(school_id,name) VALUES (?,?)',(school_id,name))
            log(c,'teacher_added',f'school_id={school_id} name={name}')
        except sqlite3.IntegrityError: flash('Professor já cadastrado ou escola inválida.','error')
    return redirect(url_for('admin'))

@app.post('/admin/codigos')
@admin_only
def codes():
    try: school_id=int(request.form.get('school','')); qty=int(request.form.get('qty',''))
    except ValueError: abort(400)
    if not 1<=qty<=500: flash('Gere entre 1 e 500 códigos por vez.','error'); return redirect(url_for('admin'))
    generated=[]
    with conn() as c:
        if not c.execute('SELECT id FROM schools WHERE id=?',(school_id,)).fetchone(): abort(400)
        for _ in range(qty):
            code='EV-'+secrets.token_hex(5).upper()
            c.execute('INSERT INTO codes(school_id,code_hash,label,created_at) VALUES (?,?,?,?)',(school_id,digest(code),None,now()))
            generated.append(code)
        log(c,'codes_generated',f'school_id={school_id} quantity={qty}')
    # Raw codes are intentionally returned once, not stored in clear text.
    out=io.StringIO(); w=csv.writer(out); w.writerow(['codigo_individual']); w.writerows([[x] for x in generated])
    return Response('\ufeff'+out.getvalue(),mimetype='text/csv',headers={'Content-Disposition':f'attachment; filename=codigos_escola_{school_id}.csv'})

@app.post('/admin/estado')
@admin_only
def state():
    opened=request.form.get('open')=='1'
    with conn() as c:
        if opened:
            empty=c.execute('''SELECT s.name FROM schools s WHERE NOT EXISTS(SELECT 1 FROM teachers t WHERE t.school_id=s.id AND t.active=1)''').fetchall()
            if empty: flash('Cadastre pelo menos um professor em cada escola antes de abrir a votação.','error'); return redirect(url_for('admin'))
        c.execute("UPDATE settings SET value=? WHERE key='open'",('1' if opened else '0',))
        log(c,'voting_opened' if opened else 'voting_closed')
    flash('Estado da votação atualizado.','ok')
    return redirect(url_for('admin'))

@app.get('/admin/exportar/<kind>')
@admin_only
def export(kind):
    if kind not in ('votes','audit','results','codes'): abort(404)
    with conn() as c:
        if kind=='votes':
            rows=c.execute('''SELECT v.id voto_id,s.name escola,t.name professor,c.id codigo_id,c.code_hash codigo_hash,v.created_at data_utc
            FROM votes v JOIN schools s ON s.id=v.school_id JOIN teachers t ON t.id=v.teacher_id JOIN codes c ON c.id=v.code_id ORDER BY v.id''').fetchall()
        elif kind=='audit': rows=c.execute('SELECT * FROM audit ORDER BY id').fetchall()
        elif kind=='codes':
            rows=c.execute('''SELECT c.id codigo_id,s.name escola,c.code_hash codigo_hash,c.created_at criado_utc,
              CASE WHEN v.id IS NULL THEN 'NAO' ELSE 'SIM' END utilizado FROM codes c JOIN schools s ON s.id=c.school_id LEFT JOIN votes v ON v.code_id=c.id ORDER BY c.id''').fetchall()
        else:
            rows=c.execute('''SELECT s.name escola,t.name professor,COUNT(v.id) votos FROM teachers t JOIN schools s ON s.id=t.school_id LEFT JOIN votes v ON v.teacher_id=t.id GROUP BY t.id ORDER BY s.id,votos DESC''').fetchall()
    out=io.StringIO(); w=csv.writer(out)
    if rows: w.writerow(rows[0].keys()); w.writerows([list(r) for r in rows])
    return Response('\ufeff'+out.getvalue(),mimetype='text/csv',headers={'Content-Disposition':f'attachment; filename={kind}.csv'})

@app.get('/saude')
def health(): return {'status':'ok'}
init()
if __name__=='__main__':
    app.run(host='127.0.0.1',port=int(os.environ.get('PORT',8080)),debug=False)
