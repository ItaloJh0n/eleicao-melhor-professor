"""Execute uma vez: python configurar.py. Guarda as credenciais em .env local."""
from pathlib import Path
from getpass import getpass
import secrets
from werkzeug.security import generate_password_hash
p=Path(__file__).with_name('.env')
if p.exists():
    raise SystemExit('Arquivo .env já existe. Não sobrescrito.')
pwd=getpass('Crie a senha de administração (mínimo 14 caracteres): ')
if len(pwd)<14: raise SystemExit('Senha muito curta.')
secret=secrets.token_hex(32)
p.write_text('SECRET_KEY='+secret+'\nADMIN_PASSWORD_HASH='+generate_password_hash(pwd)+'\nCOOKIE_SECURE=0\n',encoding='utf-8')
try: p.chmod(0o600)
except OSError: pass
print('Configuração salva em .env. Guarde a senha em local seguro.')
