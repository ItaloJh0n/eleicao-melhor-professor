# Professor Destaque 2026 — Elesbão Veloso/PI

Sistema de votação em português, com sete escolas, códigos individuais de uso único, registro transacional de votos, painel administrativo, CSV de apuração e eventos de auditoria.

## Instalação (Windows / Linux / Mac)

1. Instale Python 3.11 ou superior.
2. Abra um terminal dentro desta pasta.
3. Execute `python -m pip install -r requirements.txt`.
4. Execute `python configurar.py` e crie uma senha forte (mínimo 14 caracteres).
5. Execute `python iniciar.py`.
6. Abra `http://127.0.0.1:8080` e entre em **Administração**.
7. Cadastre todos os professores de cada uma das sete escolas.
8. Gere códigos por escola e baixe os arquivos CSV. **Guarde cada arquivo**: os códigos em texto são mostrados apenas uma vez.
9. Entregue um código exclusivo a cada estudante, preferencialmente de forma individual, com controle interno de entrega.
10. Abra a votação no painel. Os estudantes acessam a página inicial, informam seu código e votam.
11. Encerre a votação e exporte os CSVs de resultados, votos, controle de códigos e auditoria.

## Publicação na internet (obrigatória para votação em vários aparelhos)

O endereço `127.0.0.1` só funciona no próprio computador. Para uso público, hospede o sistema em servidor com HTTPS, Python/WSGI, disco persistente e backups, configure as variáveis `SECRET_KEY`, `ADMIN_PASSWORD_HASH`, `COOKIE_SECURE=1`, `DATABASE_PATH` (em disco persistente), e execute `waitress-serve --listen=127.0.0.1:8080 app:app` atrás de proxy HTTPS, ou `python iniciar.py` com as variáveis carregadas. Não use armazenamento efêmero: perder o banco de dados significa perder votos. Para produção com várias instâncias, migre o SQLite para um banco de dados centralizado antes de escalar. Configure monitoramento e backups regulares do banco, incluindo arquivos WAL quando aplicável, ou use a API de backup do SQLite.

## Limitações e garantias

- O banco garante **no máximo um voto por código**, inclusive com requisições simultâneas (restrição UNIQUE e transação). **Não comprova que uma pessoa só recebeu um código**: a escola deve distribuir e controlar os códigos com rigor.
- O sistema não exige nomes/CPF dos estudantes. A vinculação de código a aluno, caso necessária para verificação, deve ser mantida **separadamente pela escola**, com acesso restrito.
- O arquivo de votos contém identificador de código e hash, professor, escola e data/hora UTC. O administrador pode cruzar com o controle interno dos códigos distribuídos.
- Não altere a lista de candidatos após abrir a votação. Não há interface para excluir votos ou candidatos.
- O log é útil para conferência, mas não é uma trilha inviolável contra administradores com acesso direto ao servidor/banco. Para auditoria independente, faça backups assinados e controles de acesso.
- Não há empate resolvido automaticamente: defina critério em regulamento antes de iniciar.
- Os votos são confidenciais para o público, mas administradores com acesso aos arquivos podem verificar a escolha de um código. Restrinja acesso e estabeleça política de retenção e descarte.
- Rate limiting por IP é básico e não substitui WAF/proteção do provedor.
- Para segurança em produção, coloque HTTPS, controle de acesso, atualizações, backups e gestão de incidentes. Recomenda-se revisão técnica e adequação à LGPD antes de envolver menores de idade.

## Sugestão de regulamento

Um voto por estudante matriculado na unidade participante. Cada estudante escolhe um professor de sua escola considerando compromisso, responsabilidade, intencionalidade pedagógica e ética profissional. Vence o professor com mais votos válidos em cada escola. Empates serão resolvidos por critério publicado antes da votação. Definir período de votação, elegibilidade, comissão apuradora e prazo de contestação.
