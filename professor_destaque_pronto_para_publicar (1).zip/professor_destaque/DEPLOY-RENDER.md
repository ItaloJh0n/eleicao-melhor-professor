# Coloque o sistema online — Render

**Você não precisa instalar Python nem executar comandos no servidor.**

1. Crie uma conta em https://github.com e um repositório **privado** chamado `professor-destaque-2026`.
2. Envie os arquivos **de dentro** da pasta `professor_destaque` para a raiz do repositório (incluindo `render.yaml`). Não envie `data/`, banco de dados ou arquivos de códigos.
3. Crie uma conta em https://render.com, conecte o GitHub e escolha **New → Blueprint**. Selecione o repositório.
4. O Render reconhecerá `render.yaml` e criará o site, o disco persistente e a chave de sessão. Quando solicitado, defina `ADMIN_PASSWORD` com uma senha forte, exclusiva (pelo menos 16 caracteres). **Não compartilhe a senha.**
5. Confirme o plano **Starter pago** e o disco persistente. Confira os custos mostrados pelo Render antes de aceitar.
6. Aguarde a publicação. Abra o endereço `https://...onrender.com` mostrado no painel. Acesse `/admin/entrar` para entrar no painel.
7. Cadastre todos os professores, gere e distribua os códigos, depois abra a votação.

## Antes de distribuir o link
- Teste a votação com códigos de teste, em uma instalação descartável. Não faça testes com votos reais no banco de produção.
- Prepare uma lista de distribuição **um código por aluno**; só o código garante um voto por código, não um voto por pessoa sem esse controle.
- Defina regras de elegibilidade, desempate, abertura/fechamento e auditoria.
- Faça backups regulares do banco SQLite em `/var/data/votacao.db`, incluindo o estado WAL, preferencialmente usando o mecanismo de backup do SQLite. Não confie apenas no disco persistente.
- Restrinja o acesso ao painel e aos CSVs. Os arquivos exportados podem permitir rastrear a escolha de cada código.
- Use o endereço HTTPS do Render; evite expor dados pessoais de menores.

## Observações importantes
O Render pode alterar preços e recursos; confira no painel. Este projeto usa **uma instância** e **um disco persistente**. Não use planos com disco efêmero ou múltiplas instâncias com SQLite local. A senha é definida durante o deploy, não fica no código. O sistema precisa ser publicado em sua conta: um ZIP sozinho não se torna automaticamente um site público.
