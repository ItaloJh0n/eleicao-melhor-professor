from pathlib import Path
import os
p=Path(__file__).with_name('.env')
if not p.exists(): raise SystemExit('Execute primeiro: python configurar.py')
for line in p.read_text(encoding='utf-8').splitlines():
    if '=' in line and not line.startswith('#'):
        k,v=line.split('=',1); os.environ.setdefault(k,v)
from waitress import serve
from app import app
print('Sistema iniciado: http://127.0.0.1:8080')
serve(app,host=os.environ.get('HOST','127.0.0.1'),port=int(os.environ.get('PORT','8080')),threads=8)
